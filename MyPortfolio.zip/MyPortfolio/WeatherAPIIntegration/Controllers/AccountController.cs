﻿using Microsoft.AspNetCore.Mvc;
using System.Text;
using System;
using WeatherApplication.Models;
using WeatherApplication.Data;
using System.Security.Cryptography;
using Microsoft.EntityFrameworkCore;


namespace WeatherApplication.Controllers
{
    public class AccountController : Controller
    {
        private readonly AdoContext _context;
        public AccountController(AdoContext context)
        {
            _context = context;
        }

        public IActionResult Signup() => View();

        [HttpPost]
        public async Task<IActionResult> Signup(User user)
        {
            if (!ModelState.IsValid)
                return View(user);

            // Check if email already exists
            var existingUser = await _context.Users.FirstOrDefaultAsync(u => u.UserEmail == user.UserEmail);

            if (existingUser != null)
            {
                ModelState.AddModelError("UserEmail", "Email is already registered.");
                return View(user);
            }

            user.UserPassword = HashPassword(user.UserPassword);
            _context.Users.Add(user);
            _context.SaveChanges();
            return RedirectToAction("Login", "Account");
        }

        public IActionResult Login() => View();

        [HttpPost]
        public IActionResult Login(string email, string password)
        {
            var hash = HashPassword(password);
            var user = _context.Users.FirstOrDefault(u => u.UserEmail == email && u.UserPassword == hash);

            if (user == null)
            {
                ViewBag.Error = "User not found";
                return View();
            }

            if (user.UserPassword == hash)
            {
                HttpContext.Session.SetString("UserEmail", user.UserEmail);
                return RedirectToAction("Index", "Weather");
            }

            ViewBag.Error = "Invalid credentials";
            return View();
        }

        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Account","Login");
        }

        private string HashPassword(string password)
        {
            using var sha = SHA256.Create();
            var bytes = sha.ComputeHash(Encoding.UTF8.GetBytes(password));
            return Convert.ToBase64String(bytes);
        }
    }
}
