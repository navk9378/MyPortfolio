﻿using Microsoft.AspNetCore.Mvc;
using WeatherApplication.Service;

namespace WeatherApplication.Controllers
{
    public class WeatherController : Controller
    {
        private readonly WeatherService _weatherService;
        public WeatherController(WeatherService weatherService)
        {
            _weatherService = weatherService;
        }

        public IActionResult Index() => View();

        [HttpPost]
        public async Task<IActionResult> Index(string city)
        {
            var weather = await _weatherService.GetWeatherAsync(city);
            return View(weather);
        }
    }
}
