using Microsoft.EntityFrameworkCore;
using System;
using WeatherApplication.Data;
using WeatherApplication.Service;

var builder = WebApplication.CreateBuilder(args);

// Add DbContext (SQL Server, SQLite, etc.)
builder.Services.AddDbContext<AdoContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

// Add Session
builder.Services.AddDistributedMemoryCache();
builder.Services.AddSession();

// Add Controllers + Views
builder.Services.AddControllersWithViews();

// Register WeatherService
builder.Services.AddHttpClient<WeatherService>();

var app = builder.Build();

app.UseStaticFiles();
app.UseRouting();
app.UseSession();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Account}/{action=Login}/{id?}");

app.Run();
