﻿using Microsoft.Extensions.Options;
using System.Collections.Generic;
using System;
using WeatherApplication.Data;
using WeatherApplication.Models;
using Microsoft.EntityFrameworkCore;
namespace WeatherApplication.Data
{
    public class AdoContext : DbContext
    {
        public AdoContext(DbContextOptions<AdoContext> options) : base(options) { }
        public DbSet<User> Users { get; set; }
    }

}

