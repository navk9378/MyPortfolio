﻿using System.ComponentModel.DataAnnotations;

namespace WeatherApplication.Models
{
    public class User
    {
        public int UserId { get; set; }

        [Required, StringLength(100)]
        public string UserName { get; set; }

        [Required, EmailAddress]
        public string UserEmail { get; set; }

        [Required]
        public string UserPassword { get; set; }
       
    }
}
