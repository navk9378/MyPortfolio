﻿using Microsoft.AspNetCore.Mvc;
using MyPortfolio.Models;
using System.Diagnostics;
using System.Net.Mail;
using System.Net;
using System.Reflection;

namespace MyPortfolio.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly IConfiguration _config;
        public HomeController(ILogger<HomeController> logger, IConfiguration config)
        {
            _logger = logger;
            _config = config;
        }

        [HttpPost]
        public IActionResult Contact(ContactFormModel model)
        {
            if (!ModelState.IsValid)
                return View(model);

            try
            {
                string subject = "New Contact Form Submission";
                string body = $@"Name: {model.Name} 
                                Email: {model.Email} 
                                Message: {model.Message}";

                var smtpUser = _config["Smtp:UserName"];
                var smtpPass = _config["Smtp:Password"];

                using (var smtp = new SmtpClient("smtp.gmail.com", 587))
                {
                    smtp.EnableSsl = true;
                    smtp.Credentials = new NetworkCredential(smtpUser, smtpPass);

                    var mailMessage = new MailMessage
                    {
                        From = new MailAddress(smtpUser, "My Portfolio"),
                        Subject = subject,
                        Body = body,
                        IsBodyHtml = false
                    };

                    mailMessage.To.Add(smtpUser);
                    mailMessage.ReplyToList.Add(new MailAddress(model.Email));

                    smtp.Send(mailMessage);
                }

                TempData["SuccessMessage"] = "Thank you! Your message has been sent successfully.";
                return RedirectToAction("Contact", new { success = true });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error sending contact form email");
                ViewBag.Message = "Error sending email. Please try again later.";
                return View(model);
            }
        }

        [HttpGet]
        public IActionResult Contact(bool success = false)
        {
            if (success)
                TempData["SuccessMessage"] = "Thank you! Your message has been sent successfully.";

            return View();
        }


        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
