﻿namespace MyPortfolio.Models
{
    public class Project
    {
        public string Title { get; set; }
        public string Description { get; set; }
        public string Features { get; set; }
        public string TechStack { get; set; }
        public string GitHubLink { get; set; }
        public String ProjectLink { get; set; }
        public string ImageUrl { get; set; }
        public string ProjectType {  get; set; }
        public string ImageAltText {  get; set; }

    }

}
