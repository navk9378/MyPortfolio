﻿using Microsoft.AspNetCore.Mvc;
using MyPortfolio.Models;
using System.Collections.Generic;

public class ProjectsViewComponent : ViewComponent
{
    public IViewComponentResult Invoke()
    {
        var projects = new List<Project>
        {
            new Project
            {
                Title = "Weather API Integration",
                Description = "Web app consuming a public API to display live weather data based on user location.",
                ProjectType = "API / Integration",
                Features = "API integration, dynamic display of weather information, responsive UI, error handling for API failures.",
                ImageAltText ="Weather, climate icons, location",
                TechStack = "ASP.NET Core Web API, MVC, JavaScript, HTML, CSS, Bootstrap",
                GitHubLink = "https://github.com/navk9378/weather-app",
                ImageUrl = "~/images/WeatherAPP.png"
            },

            new Project
            {
                Title = "Student Management System",
                Description = "A console-based C# project to manage students — demonstrating all major C# concepts such as OOP, file handling, LINQ, delegates, and async operations.",
                ProjectType = "Console Application",
                Features = "Add, update, delete, and view students; file-based data storage; LINQ search; exception handling; events and async file I/O.",
                TechStack = "C#, .NET Console, File I/O, LINQ, Async/Await",
                GitHubLink = "https://github.com/navk9378/Student-Management-System",
                ImageAltText = "Console app displaying student records and CRUD operations",
                ImageUrl = "~/images/inventory.jpeg"
            },

           //new Project
           //{
           //     Title = "Smart Inventory System",
           //     Description = "An enterprise-level web application designed to manage stock levels, suppliers, orders, and analytics using a modular microservice architecture. Includes dashboards, role-based access, and interactive charts.",
           //     ProjectType = "Enterprise / Microservices App",
           //     Features = "Product and supplier management, purchase and sales tracking, real-time inventory updates, RESTful APIs for communication between services, JWT-based authentication, and analytics dashboard using Chart.js.",
           //     TechStack = "ASP.NET Core Web API (Microservices), MVC, C#, SQL Server, Entity Framework Core, LINQ, Repository Pattern, CQRS, JWT Authentication, Chart.js, HTML, CSS, JavaScript, Bootstrap, Serilog, Swagger",
           //     ImageAltText = "Inventory management, analytics dashboard, warehouse, charts",
           //     GitHubLink = "https://github.com/navk9378/SmartInventorySystem",
           //     ImageUrl = "~/images/inventory-dashboard.png"
           //},

            new Project
            {
                Title = "School Management System",
                Description = "A comprehensive backend API built with .NET Core Web API to manage students, teachers, courses, classes, attendance, assignments, and grades. Features role-based access control for Admins, Teachers, and Students, with secure JWT authentication and relational database design using Entity Framework Core.",
                ProjectType = "Educational / Web API",
                Features = "User management, department and course management, class scheduling, student enrollment, attendance tracking, assignment creation and submission, grading system, notifications, and role-based access control. Includes validation rules, async database operations, caching, and logging with Serilog.",
                TechStack = "ASP.NET Core Web API, C#, SQL Server, Entity Framework Core, JWT Authentication, AutoMapper, FluentValidation, Serilog, Swagger",
                ImageAltText = "School Management, Students, Teachers, Classes, Assignments",
                GitHubLink = "https://github.com/navk9378/SchoolManagementSystem",
                ImageUrl = "~/images/SchoolManagemnt.png"
            },


            new Project
            {
                Title = "Task Tracker App",
                Description = "A full-stack project management application that allows teams to create, assign, and track tasks with real-time collaboration and progress visualization. Inspired by tools like Trello and Asana.",
                ProjectType = "Full-Stack Web App",
                Features = "User authentication and authorization, create/update tasks, assign users, drag-and-drop task boards, real-time task updates using SignalR, commenting system, and analytics using Chart.js.",
                TechStack = "ASP.NET Core MVC, C#, ASP.NET Core Web API, SQL Server, Entity Framework Core, LINQ, SignalR, JavaScript, jQuery, AJAX, Bootstrap, HTML, CSS, Repository Pattern, SOLID Principles",
                ImageAltText = "Project management, task board, collaboration, real-time updates",
                GitHubLink = "https://github.com/navk9378/TaskTrackerApp",
                ImageUrl = "~/images/tasktracker.png"
            },


            new Project
            {
                Title = "Online Hotel Booking App",
                Description = "A full-stack web application for browsing menus, adding food items to the cart, making secure payments, and managing orders — all built using ASP.NET Core MVC.",
                ProjectType = "E-Commerce / Online Hotel Booking App",
                Features = "User authentication (login/register), food browsing, cart management, order checkout, payment integration, responsive UI, and admin panel for managing items.",
                TechStack = "ASP.NET Core MVC, C#, Entity Framework Core, SQL Server, Identity Framework, Bootstrap, JavaScript, HTML, CSS",
                ImageAltText = "Hotel Booking, online ordering, cart, meals",
                GitHubLink = "https://github.com/navk9378/OnlineFoodOrderingApp",
                ImageUrl = "~/Images/FoodApps.png"
            },


            new Project
            {
                Title = "Delicious Design Lab",
                Description = "A front-end centric web application built to highlight UI perfection, responsive design, and seamless interactivity using HTML, CSS, JavaScript, and jQuery. The project includes interactive forms, dynamic animations, modals, sliders, and API-based content loading to simulate a real product experience.",
                ProjectType = "Front-End / UI Showcase",
                Features = "Fully responsive design with smooth animations, interactive modals and sliders, AJAX-based API calls for live content, form validations, dynamic filtering and sorting, and reusable UI components built with clean CSS architecture.",
                TechStack = "HTML5, CSS3, Bootstrap, JavaScript, jQuery, AJAX, JSON, Font Awesome, Animate.css",
                ImageAltText = "Modern UI design, responsive layout, animation, interactive web components",
                GitHubLink = "https://github.com/navk9378/DeliciousDesignLab",
                ImageUrl = "~/Images/FoodApp.png"
            },


        };

        return View("/Views/Home/_ProjectsPartial.cshtml", projects);

    }
}
